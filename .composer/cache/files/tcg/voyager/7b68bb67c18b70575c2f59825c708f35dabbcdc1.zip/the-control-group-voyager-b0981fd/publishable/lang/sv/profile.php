<?php

return [
    'avatar'           => 'Avatar',
    'edit'             => 'Redigera Min Profil',
    'edit_user'        => 'Redigera Användare',
    'password'         => 'Lösenord',
    'password_hint'    => 'Lämna tomt för att behålla samma',
    'role'             => 'Roll',
    'roles'            => 'Roller',
    'role_default'     => 'Förvald Roll',
    'roles_additional' => 'Ytterligare Roller',
    'user_role'        => 'Användarens Roll',
];
