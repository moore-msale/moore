# Number

```php
{
    "step" : 0.1,
    "min" : 0,
    "max" : 10
}
```

These are standard attributes for number input field, default value for step is any if not defined.
