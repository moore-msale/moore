<?php

return [
    'last_week' => 'A semana pasada',
    'last_year' => 'O ano pasado',
    'this_week' => 'Esta semana',
    'this_year' => 'Este ano',
];
