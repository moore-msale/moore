<?php

return [
    'footer_copyright' 	=> 'Gjord me <i class="voyager-heart"></i> av',
    'footer_copyright2' => 'Gjord på rom och ännu mer rom',
];
