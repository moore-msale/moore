<?php

return [
    'footer_copyright'  => 'Vytvořeno s <i class="voyager-heart"></i> od',
    'footer_copyright2' => 'Vytvořeno s rumem',
];
