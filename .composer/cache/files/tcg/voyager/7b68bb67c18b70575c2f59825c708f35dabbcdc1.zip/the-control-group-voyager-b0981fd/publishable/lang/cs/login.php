<?php

return [
    'loggingin'    => 'Přihlašuji',
    'signin_below' => 'Přihlašte se:',
    'welcome'      => 'Vítá vás Voyager, chybějící administrace pro Laravel',
];
