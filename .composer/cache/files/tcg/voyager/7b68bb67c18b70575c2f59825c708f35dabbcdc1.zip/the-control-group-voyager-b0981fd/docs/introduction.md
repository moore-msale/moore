# Introduction

Welcome to the Voyager documentation for version 1.2. This documentation will teach you how to install, configure, and use Voyager so that way you can create some kick ass stuff!

Hm Hm \(cough\)… I mean… Arrgg! Ye young scallywag! What say we learn how to steer this ship!

![Voyager Screenshot](https://s3.amazonaws.com/thecontrolgroup/voyager-screenshot.png)

Before installing Voyager you may want to take a quick moment to learn what is is and what it isn't, we'll do that in the next section.

