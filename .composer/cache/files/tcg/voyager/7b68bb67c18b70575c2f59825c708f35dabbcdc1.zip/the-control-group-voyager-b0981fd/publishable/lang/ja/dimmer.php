<?php

return [
    'page'           => 'ページ|ページ',
    'page_link_text' => 'すべてのページを表示',
    'page_text'      => 'データベースに:count:stringが存在します。 すべての:stringを表示するには下記のボタンをクリックください。',
    'post'           => '投稿|投稿',
    'post_link_text' => 'すべての投稿を表示',
    'post_text'      => 'データベースに:count:stringが存在します。 すべての:stringを表示するには下記のボタンをクリックください。',
    'user'           => 'ユーザー|ユーザー',
    'user_link_text' => 'すべてのユーザーを表示',
    'user_text'      => 'データベースに:count:stringが存在します。 すべての:stringを表示するには下記のボタンをクリックください。',
];
