<?php

return [
    'field_password_keep'          => 'Jätä tyhjäksi jos et halua muuttaa',
    'field_select_dd_relationship' => 'Varmistathan että lisäät tarpeellisen riippuvuustiedon metodiin :method luokassa :class.',
    'type_checkbox'                => 'Valintaruutu',
    'type_codeeditor'              => 'Koodieditori',
    'type_file'                    => 'Tiedosto',
    'type_image'                   => 'Kuva',
    'type_radiobutton'             => 'Vaihtoehtonappi',
    'type_richtextbox'             => 'Rikastekstieditori',
    'type_selectdropdown'          => 'Alasvetolista',
    'type_textarea'                => 'Tekstialue',
    'type_textbox'                 => 'Tekstilaatikko',
];
