<?php

return [
    'footer_copyright'  => 'Produzido com <i class="voyager-heart"></i> por',
    'footer_copyright2' => 'Produzido com rum e mais rum',
];
