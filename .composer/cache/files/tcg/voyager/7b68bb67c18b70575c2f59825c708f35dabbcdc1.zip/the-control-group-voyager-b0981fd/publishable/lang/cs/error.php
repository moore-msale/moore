<?php

return [
    'symlink_created_text'  => 'Vytvořili jsme chybějící symlink pro vás.',
    'symlink_created_title' => 'Chybějící storage symlink vytvořen',
    'symlink_failed_text'   => 'Nepodařilo se nám vytvořit chybějící symlink pro vaši aplikaci. '.
                                'Vypadá to, že to váš hosting nepodporuje.',
    'symlink_failed_title'   => 'Nepodařilo se vytvořit storage symlink',
    'symlink_missing_button' => 'Opravit to',
    'symlink_missing_text'   => 'Nemohli jsme najít storage symlink. To může dělat problémy s '.
                                'načítáním souborů z prohlížeče.',
    'symlink_missing_title' => 'Chybějící storage symlink',
];
