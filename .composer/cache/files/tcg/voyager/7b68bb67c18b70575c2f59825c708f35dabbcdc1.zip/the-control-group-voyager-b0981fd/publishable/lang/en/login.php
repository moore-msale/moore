<?php

return [
    'loggingin'    => 'Logging in',
    'signin_below' => 'Sign In Below:',
    'welcome'      => 'Welcome to Voyager. The Missing Admin for Laravel',
];
