<?php

return [
    'last_week' => 'Javën e kaluar',
    'last_year' => 'Viti i kaluar',
    'this_week' => 'Kjo javë',
    'this_year' => 'Këtë vit',
];
