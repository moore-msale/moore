<?php

return [
    'by_pageview'            => 'Por pageview',
    'by_sessions'            => 'Por sessões',
    'by_users'               => 'Por usuário',
    'no_client_id'           => 'Para logar no analytics é preciso adicionar a chave <code>google_analytics_client_id</code> nas Configurações do Voyager com o código google de identidade do analytics client. Obtenha o sua chave através do Google developer console:',
    'set_view'               => 'Selecionar Vista',
    'this_vs_last_week'      => 'Esta Semana vs Semana Passada',
    'this_vs_last_year'      => 'Este Ano vs Ano Passado',
    'top_browsers'           => 'Top Browsers',
    'top_countries'          => 'Top Países',
    'various_visualizations' => 'Visualizações várias',
];
