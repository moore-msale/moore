<?php

return [
    'by_pageview'            => 'Per pageview',
    'by_sessions'            => 'Per sessioni',
    'by_users'               => 'Per utenti',
    'no_client_id'           => 'Per visualizzare le analisi, dovrai ottenere un client ID per Google Analytics e aggiungerlo alle tue impostazioni per la chiave <code>google_analytics_client_id</code>. ottieni una chiave su Google developer console:',
    'set_view'               => 'Seleziona una Vista',
    'this_vs_last_week'      => 'Questa settimana vs la scorsa settimana',
    'this_vs_last_year'      => 'Quest\'anno vs lo scorso anno',
    'top_browsers'           => 'Browser Top',
    'top_countries'          => 'Paesi Top',
    'various_visualizations' => 'Varie visualizzazioni',
];
